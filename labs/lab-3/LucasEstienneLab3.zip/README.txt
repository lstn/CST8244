# Lucas Estienne's CST8244 Lab 3 - Processes & Signals
## Status
For part A, the project builds successfully,
meets all the requirements, handles SIGUSR1 properly, v
ariables are declared with the requested types, etc.
For part B, the project builds, meets all the requirements,
and does not leave orphan processes running if you try to send SIGUSR1 to the parent.
## Known Issues
None.
## Expected Grade
I expect the full 5 points for part A and the full 10 points for part B.